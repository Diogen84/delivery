export class RelationModel {
    id: number;
    productId: number;
    categoryId: number;
}