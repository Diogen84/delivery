export class CategoryModel {
    id: number;
    name: string;
    thumbnail: any;
    shortDescription : string;
    description : string;
    lock : boolean;
    created : string;
    edited : string;
}