export class OrderModel {
    productId : number;
    amount : number;
}