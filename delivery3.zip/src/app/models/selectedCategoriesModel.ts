export class CategoryItem {
    public value: number;
    public name: string;

    public constructor(p :number, n : string) {
        this.name = n;
        this.value = p;
    }
}