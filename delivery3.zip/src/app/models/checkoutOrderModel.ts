export class CheckoutOrderModel {
    date: any;
    name: string;
    phone: string;
    address: string;
    additional: any;
    products: any;
}