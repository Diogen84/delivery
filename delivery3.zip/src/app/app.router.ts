import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { Index } from './components/front/indexPage';
import { CategoryList } from './components/admin/categoryList';
import { CategoryDetail } from './components/admin/categoryDetail';
import { ProductList } from './components/admin/productList';
import { ProductDetail } from './components/admin/productDetail';

const routes: Routes = [
    //front
    { path: '', redirectTo: 'index', pathMatch: 'full' },
    { path: 'index', component: Index },

    //admin
    { path: 'admin/categories', component: CategoryList },
    { path: 'admin/categories/:id', component: CategoryDetail },
    { path: 'admin/products', component: ProductList },
    { path: 'admin/products/:id', component: ProductDetail }
];

@NgModule({
    imports: [ RouterModule.forRoot(routes) ],
    exports: [ RouterModule ]
})
export class AppRoutingModule {}